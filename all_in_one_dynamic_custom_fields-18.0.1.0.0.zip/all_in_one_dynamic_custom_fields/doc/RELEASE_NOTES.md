## Module <all_in_one_dynamic_custom_fields>

#### 2.11.2024
#### Version 18.0.1.0.0
##### ADD

- Initial commit for All in One Dynamic Fields
