{
    'name': 'Prise de Notes',
    'version': '1.0',
    'category': 'Productivity',
    'summary': 'Module de prise de notes avec gestion des échéances',
    'description': """
        Module de prise de notes permettant de :
        * Créer et gérer des notes
        * Définir des échéances pour les notes
        * Organiser les notes par catégories
        * Suivre l'état des notes
    """,
    'author': 'Votre Nom',
    'website': 'https://www.votresite.com',
    'depends': ['base', 'mail', 'hr'],
    'data': [
        'security/ir.model.access.csv',
        'views/note_views.xml',
        'views/note_deadline_views.xml',
        'views/menu_views.xml',
        'data/note_tags_data.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'prise_de_notes/static/src/xml/color_picker.xml',
            'prise_de_notes/static/src/css/note_colors.css',
        ],
    },
    'installable': True,
    'application': True,
    'auto_install': False,
}
