# prise_de_notes/__init__.py
from . import models
