# Module Prise de Notes - Odoo 18

## Description

Module complet de prise de notes pour Odoo Community v18 permettant la gestion des réunions, participants, délais et organisation avec un système d'étiquettes et de couleurs.

## Fonctionnalités

- ✅ Création de notes de réunion avec éditeur HTML
- ✅ Gestion des participants (contacts Odoo)
- ✅ Système d'étiquettes avec couleurs
- ✅ Codes couleur pour l'organisation
- ✅ Gestion des délais avec échéances
- ✅ Vue calendrier pour réunions et délais
- ✅ Interface moderne (Kanban, Liste, Formulaire)
- ✅ Suivi des tâches terminées/à faire

## Installation

1. Copier le dossier `prise_de_notes` dans le répertoire addons d'Odoo
2. Redémarrer Odoo
3. Aller dans Apps > Mettre à jour la liste des applications
4. Rechercher "Prise de Notes" et installer

## Utilisation

1. Accéder au menu "Prise de Notes"
2. Créer une nouvelle note avec le bouton "Nouveau"
3. Remplir les informations : titre, participants, étiquettes
4. Ajouter le contenu dans l'onglet "Note"
5. Définir les délais dans l'onglet "Délais"
6. Utiliser la vue calendrier pour visualiser les plannings

## Support

Module développé pour Odoo Community v18.
