from odoo import models, fields, api

class NoteDeadline(models.Model):
    _name = 'note.deadline'
    _description = 'Délai de note'
    _order = 'deadline_date asc'
    _rec_name = 'title'

    title = fields.Char(string='Titre', required=True)
    deadline_date = fields.Datetime(string='Date limite', required=True)
    note_id = fields.Many2one('note.note', string='Note', required=True, ondelete='cascade')
    participant_ids = fields.Many2many(
        'res.partner',
        string='Participants',
        domain=[('is_company', '=', False)]
    )
    color = fields.Selection([
        ('0', 'Blanc'),
        ('1', 'Rouge'),
        ('2', 'Orange'),
        ('3', 'Jaune'),
        ('4', 'Vert clair'),
        ('5', 'Vert'),
        ('6', 'Cyan'),
        ('7', 'Bleu'),
        ('8', 'Violet'),
        ('9', 'Rose'),
        ('10', 'Gris'),
        ('11', 'Noir'),
    ], string='Couleur', default='1')

    description = fields.Text(string='Description')
    is_completed = fields.Boolean(string='Terminé', default=False)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if 'color' in vals and isinstance(vals['color'], int):
                vals['color'] = str(vals['color'])
        return super().create(vals_list)

    def write(self, vals):
        if 'color' in vals and isinstance(vals['color'], int):
            vals['color'] = str(vals['color'])
        return super().write(vals)

    def action_mark_completed(self):
        self.write({'is_completed': True})

    def action_mark_todo(self):
        self.write({'is_completed': False})
