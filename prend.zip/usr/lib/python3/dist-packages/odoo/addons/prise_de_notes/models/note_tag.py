from odoo import models, fields

class NoteTag(models.Model):
    _name = 'note.tag'
    _description = 'Étiquette de note'
    _order = 'name'

    name = fields.Char(string='Nom', required=True)
    color = fields.Integer(
    string='Couleur', 
    default=0,
    help='Index de couleur : 0=Blanc, 1=Rouge, 2=Orange, 3=Jaune, 4=Vert clair, 5=Vert, 6=Cyan, 7=Bleu, 8=Violet, 9=Rose, 10=Gris, 11=Noir'
)
    note_ids = fields.Many2many('note.note', string='Notes')
    
    _sql_constraints = [
        ('name_unique', 'unique(name)', 'Le nom de l\'étiquette doit être unique.')
    ]
