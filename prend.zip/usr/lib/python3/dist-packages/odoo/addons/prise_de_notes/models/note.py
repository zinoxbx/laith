from odoo import models, fields, api
from odoo.exceptions import ValidationError, AccessError
import logging

_logger = logging.getLogger(__name__)

class SafeMany2one(fields.Many2one):
    """Version simplifiée de SafeMany2one qui gère les références cassées"""
    
    def convert_to_read(self, value, record, use_display_name=True):
        """Gère les références cassées lors de la lecture"""
        try:
            return super().convert_to_read(value, record, use_display_name)
        except (AttributeError, AccessError) as e:
            error_msg = str(e)
            if ("'_unknown'" in error_msg or 
                "Inconnu" in error_msg or
                "_unknown" in error_msg):
                
                _logger.warning(f"Référence cassée détectée dans {record._name}.{self.name} pour l'enregistrement {record.id}")
                
                # Nettoyer la référence cassée
                if hasattr(record, 'id') and record.id:
                    self._cleanup_broken_reference(record, self.name)
                
                return False
            raise
    
    def _cleanup_broken_reference(self, record, field_name):
        """Nettoie une référence cassée spécifique"""
        try:
            if isinstance(record.id, int) and record.id > 0:
                # Nettoyer en base de données
                record.env.cr.execute(
                    f"UPDATE {record._table} SET {field_name} = NULL WHERE id = %s",
                    (record.id,)
                )
                # Invalider le cache
                record.invalidate_recordset([field_name])
                _logger.info(f"Référence cassée nettoyée : {record._name}.{field_name} pour l'enregistrement {record.id}")
        except Exception as e:
            _logger.error(f"Erreur lors du nettoyage de la référence cassée : {e}")

class Note(models.Model):
    _name = 'note.note'
    _description = 'Note de réunion'
    _order = 'meeting_date desc, id desc'
    _rec_name = 'title'

    department_id = SafeMany2one(
        'hr.department',
        string='Département',
        ondelete='set null',
        domain=[('active', '=', True)]
    )
    title = fields.Char(string='Titre', required=True)
    meeting_date = fields.Datetime(
        string='Date de la réunion',
        default=fields.Datetime.now,
        required=True
    )
    content = fields.Html(string='Contenu de la note')
    participant_ids = fields.Many2many(
        'res.partner',
        string='Participants',
        domain=[('is_company', '=', False)]
    )
    tag_ids = fields.Many2many(
        'note.tag',
        string='Étiquettes'
    )
    color = fields.Selection([
        ('0', 'Blanc'),
        ('1', 'Rouge'),
        ('2', 'Orange'),
        ('3', 'Jaune'),
        ('4', 'Vert clair'),
        ('5', 'Vert'),
        ('6', 'Cyan'),
        ('7', 'Bleu'),
        ('8', 'Violet'),
        ('9', 'Rose'),
        ('10', 'Gris'),
        ('11', 'Noir'),
    ], string='Couleur', default='0')
    deadline_ids = fields.One2many(
        'note.deadline',
        'note_id',
        string='Délais'
    )
    deadline_count = fields.Integer(
        string='Nombre de délais',
        compute='_compute_deadline_count'
    )
    active = fields.Boolean(default=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals = self._secure_vals(vals)
            if vals.get('department_id'):
                self._validate_department(vals['department_id'])
        return super().create(vals_list)

    def write(self, vals):
        vals = self._secure_vals(vals)
        if 'department_id' in vals and vals['department_id']:
            self._validate_department(vals['department_id'])
        return super().write(vals)

    def _secure_vals(self, vals):
        """Sécurise les valeurs avant création/modification"""
        # Sécuriser department_id
        if 'department_id' in vals and isinstance(vals['department_id'], dict):
            vals['department_id'] = vals['department_id'].get('id', False)
        
        # Sécuriser color
        if 'color' in vals and isinstance(vals['color'], int):
            vals['color'] = str(vals['color'])
        
        return vals

    def _validate_department(self, department_id):
        """Valide que le département existe et est actif"""
        if department_id:
            try:
                department = self.env['hr.department'].browse(department_id)
                if not department.exists():
                    raise ValidationError(f"Le département avec l'ID {department_id} n'existe pas.")
                if not department.active:
                    raise ValidationError(f"Le département {department.name} n'est pas actif.")
            except AccessError:
                raise ValidationError(f"Le département avec l'ID {department_id} n'est pas accessible.")

    @api.model
    def search_read(self, domain=None, fields=None, offset=0, limit=None, order=None):
        """Recherche sécurisée avec nettoyage préventif"""
        # Nettoyer les références cassées avant la recherche
        self._cleanup_invalid_departments()
        return super().search_read(domain, fields, offset, limit, order)

    def read(self, fields=None, load='_classic_read'):
        """Lecture sécurisée avec gestion des références cassées"""
        try:
            return super().read(fields, load)
        except (AttributeError, AccessError) as e:
            if "_unknown" in str(e) or "Inconnu" in str(e):
                _logger.warning(f"Références cassées détectées lors de la lecture des enregistrements {self.ids}")
                # Nettoyer les références cassées
                self._emergency_cleanup_self()
                # Réessayer la lecture
                try:
                    return super().read(fields, load)
                except:
                    # Si ça échoue encore, retourner des données minimales
                    return self._get_safe_read_data(fields)
            raise

    def _emergency_cleanup_self(self):
        """Nettoyage d'urgence des références cassées pour les enregistrements actuels"""
        if not self.ids:
            return
        
        try:
            # Nettoyer department_id
            self.env.cr.execute("""
                UPDATE note_note 
                SET department_id = NULL 
                WHERE id = ANY(%s) 
                AND department_id IS NOT NULL 
                AND (department_id NOT IN (
                    SELECT id FROM hr_department WHERE id IS NOT NULL AND active = true
                ) OR department_id IN (
                    SELECT id FROM hr_department WHERE active = false
                ))
            """, (list(self.ids),))
            
            if self.env.cr.rowcount > 0:
                self.invalidate_recordset(['department_id'])
                _logger.info(f"Nettoyage d'urgence : {self.env.cr.rowcount} références department_id")
                
        except Exception as e:
            _logger.error(f"Erreur lors du nettoyage d'urgence : {e}")

    def _get_safe_read_data(self, fields):
        """Retourne des données sécurisées en cas d'échec de lecture"""
        result = []
        for record_id in self.ids:
            data = {'id': record_id}
            if not fields or 'title' in fields:
                data['title'] = 'Titre non disponible'
            if not fields or 'meeting_date' in fields:
                data['meeting_date'] = fields.Datetime.now()
            if not fields or 'department_id' in fields:
                data['department_id'] = False
            if not fields or 'color' in fields:
                data['color'] = '0'
            if not fields or 'active' in fields:
                data['active'] = True
            result.append(data)
        return result

    @api.depends('deadline_ids')
    def _compute_deadline_count(self):
        for record in self:
            try:
                record.deadline_count = len(record.deadline_ids)
            except (AttributeError, AccessError):
                record.deadline_count = 0

    def action_view_deadlines(self):
        self.ensure_one()
        return {
            'name': 'Délais',
            'type': 'ir.actions.act_window',
            'res_model': 'note.deadline',
            'view_mode': 'list,form',
            'domain': [('note_id', '=', self.id)],
            'context': {'default_note_id': self.id},
        }

    @api.model
    def _cleanup_invalid_departments(self):
        """Nettoie les références de département invalides ou inactives"""
        try:
            self.env.cr.execute("""
                SELECT COUNT(*) FROM note_note nn 
                LEFT JOIN hr_department hd ON nn.department_id = hd.id 
                WHERE nn.department_id IS NOT NULL 
                AND (hd.id IS NULL OR hd.active = false)
            """)
            
            count = self.env.cr.fetchone()[0]
            if count > 0:
                self.env.cr.execute("""
                    UPDATE note_note 
                    SET department_id = NULL 
                    WHERE department_id IS NOT NULL 
                    AND (department_id NOT IN (
                        SELECT id FROM hr_department WHERE id IS NOT NULL AND active = true
                    ) OR department_id IN (
                        SELECT id FROM hr_department WHERE active = false
                    ))
                """)
                _logger.info(f"Nettoyage automatique : {count} références department_id invalides/inactives")
            
            return count
        except Exception as e:
            _logger.error(f"Erreur lors du nettoyage automatique : {e}")
            return 0

    @api.model 
    def action_cleanup_broken_references(self):
        """Action manuelle pour nettoyer les références cassées"""
        cleaned = self._cleanup_invalid_departments()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Nettoyage terminé',
                'message': f'{cleaned} références de département ont été nettoyées.',
                'type': 'success',
            }
        }

    @api.model
    def cron_cleanup_broken_references(self):
        """Tâche cron pour nettoyer les références cassées"""
        _logger.info("Démarrage du nettoyage automatique des références cassées...")
        cleaned = self._cleanup_invalid_departments()
        _logger.info(f"Nettoyage terminé : {cleaned} références réparées")
        return True
