{
    'name': 'Prise de Notes',
    'version': '18.0.1.0.0',
    'category': 'Productivity',
    'summary': 'Module de prise de notes avec gestion des réunions et délais',
    'description': '''
        Module complet de prise de notes permettant :
        - Création et gestion de notes de réunion
        - Gestion des participants
        - Système d'étiquettes
        - Gestion des délais et échéances
        - Vue calendrier intégrée
        - Codes couleur pour l'organisation
    ''',
    'author': 'Votre Société',
    'website': 'https://www.votresite.com',
    'depends': ['base', 'web', 'calendar'],
    'data': [
        'data/note_tags_data.xml',
        'views/note_views.xml',
        'views/note_deadline_views.xml',
        'views/menu_views.xml',
        'security/ir.model.access.csv',
    ],
    'assets': {
        'web.assets_backend': [
            'prise_de_notes/static/src/css/note_colors.css',
        ],
    },
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
