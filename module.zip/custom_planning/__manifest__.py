{
    'name': 'Custom Planning',
    'version': '18.0.1.0.0',
    'category': 'Human Resources',
    'summary': 'Community version of Employee Planning.',
    'description': """
        Custom Planning Module
        =====================
        This module allows you to manage employee shifts and planning.
        Features:
        - Create and manage employee shifts
        - View planning in different formats (Kanban, List, Form)
        - Track shift status
    """,
    'author': 'Your Name',
    'website': 'https://www.yourcompany.com',
    'depends': [
        'hr',
        'web',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/planning_views.xml',
        'views/planning_menus.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'custom_planning/static/src/js/**/*',
            'custom_planning/static/src/css/**/*',
        ],
    },
    'images': ['static/description/icon.png'],
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
