from odoo import models, fields
class CustomPlanningShift(models.Model):
    _name = 'custom.planning.shift'
    _description = 'Custom Planning Shift'
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    start_datetime = fields.Datetime(required=True)
    end_datetime = fields.Datetime(required=True)
    role = fields.Char("Role")
