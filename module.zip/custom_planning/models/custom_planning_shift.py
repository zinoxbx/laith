from odoo import models, fields, api

class CustomPlanningShift(models.Model):
    _name = 'custom.planning.shift'
    _description = 'Planning Shift'
    _order = 'start_datetime'

    name = fields.Char(string='Name', compute='_compute_name', store=True)
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    role = fields.Char(string='Role', required=True)
    start_datetime = fields.Datetime(string='Start Date', required=True)
    end_datetime = fields.Datetime(string='End Date', required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled')
    ], string='Status', default='draft', required=True)

    @api.depends('employee_id', 'role', 'start_datetime')
    def _compute_name(self):
        for shift in self:
            if shift.employee_id and shift.role and shift.start_datetime:
                shift.name = f"{shift.employee_id.name} - {shift.role} ({shift.start_datetime.strftime('%Y-%m-%d')})"
            else:
                shift.name = "New Shift" 