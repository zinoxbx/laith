{
    'name': 'Custom Subscriptions',
    'version': '18.0.1.0.0',
    'category': 'Sales',
    'summary': 'Community version of Subscription Management.',
    'author': 'Your Name',
    'depends': ['sale_management', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/subscription_views.xml',
        'views/subscription_menus.xml',
    ],
    'application': True,
    'license': 'LGPL-3',
}
