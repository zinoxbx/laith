from odoo import models, fields
class CustomSubscription(models.Model):
    _name = 'custom.subscription'
    _description = 'Custom Subscription'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    name = fields.Char(required=True)
    partner_id = fields.Many2one('res.partner', string='Customer', required=True)
    state = fields.Selection([('draft', 'Draft'), ('running', 'In Progress'), ('closed', 'Closed')], default='draft', tracking=True)
    start_date = fields.Date(default=fields.Date.context_today)
    next_invoice_date = fields.Date()
