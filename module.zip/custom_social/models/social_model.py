from odoo import models, fields
class CustomSocialPost(models.Model):
    _name = 'custom.social.post'
    _description = 'Custom Social Post'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    message = fields.Text(required=True)
    state = fields.Selection([('draft', 'Draft'), ('scheduled', 'Scheduled'), ('posted', 'Posted')], default='draft', tracking=True)
    scheduled_date = fields.Datetime()
    platform = fields.Selection([('facebook', 'Facebook'), ('twitter', 'Twitter'), ('linkedin', 'LinkedIn')])
