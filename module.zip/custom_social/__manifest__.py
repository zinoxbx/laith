{
    'name': 'Custom Social Marketing',
    'version': '18.0.1.0.0',
    'category': 'Marketing',
    'summary': 'Community version of Social Marketing.',
    'description': """
        Custom Social Marketing Module
        ============================
        This module allows you to manage your social media posts.
    """,
    'author': 'Your Name',
    'website': 'https://www.example.com',
    'depends': ['base', 'mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/social_views.xml',
        'views/social_menus.xml',
    ],
    'assets': {
        'web.assets_backend': [
            '/custom_social/static/src/css/style.css',
        ],
    },
    'images': ['static/description/icon.png'],
    'icon': '/custom_social/static/description/icon.png',
    'application': True,
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
